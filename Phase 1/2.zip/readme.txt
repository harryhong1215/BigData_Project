1. Group information
Group ID: 2
Group Members: 
Lai Kam Hong (khlaiaf, 20310528)
Chan Chi Kuen (ckchanbh, 20318185)

2. File list
|--main.py
|--readme.txt

3. File description
main.py - softcopy of python program
readme.txt - information of the program and detail of the group

4. Method of execution
python main.py

5. Known bugs of your system 
No
